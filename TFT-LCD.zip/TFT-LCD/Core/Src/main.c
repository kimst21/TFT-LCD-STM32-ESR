/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : ILI9341 LCD를 이용한 그래픽 출력 프로그램
  ******************************************************************************
  * @attention
  * - 본 코드는 STM32F407VET6 보드에서 ILI9341 LCD를 사용하여 다양한 그래픽을 출력하는 기능을 수행합니다.
  * - SPI 통신을 사용하며, LCD 초기화 후 기본적인 텍스트 및 도형을 출력하는 예제입니다.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "spi.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ILI9341_STM32_Driver.h"  // ILI9341 LCD 드라이버 라이브러리
#include "ILI9341_GFX.h"           // ILI9341 그래픽 라이브러리
#include <stdio.h>                 // sprintf()를 위한 표준 입출력 라이브러리
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
static char BufferText[30];  // 문자열 저장 버퍼
/* USER CODE END PV */

/* Function prototypes -------------------------------------------------------*/
void SystemClock_Config(void);

/* USER CODE BEGIN 0 */
// 사용자 정의 코드 작성 영역
/* USER CODE END 0 */

/**
  * @brief  Main application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  // 시스템 초기화 단계
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_SPI4_Init();

  /* USER CODE BEGIN 2 */
  ILI9341_Init();  // LCD 초기화
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
      // LCD 화면 초기화 및 텍스트 출력
      ILI9341_FillScreen(WHITE);
      ILI9341_SetRotation(SCREEN_HORIZONTAL_2);  // 가로 모드 설정

      // "HELLO All-In_one ESR Board" 텍스트 출력
      ILI9341_DrawText("HELLO All-In_one ESR Board", FONT4, 30, 90, BLACK, WHITE);
      HAL_Delay(2000); // 2초 대기

      /* ================== [1] 다양한 색상의 텍스트 출력 ================== */
      ILI9341_FillScreen(WHITE);  // 화면 초기화

      sprintf(BufferText, "FUNCTION : ");  // 출력할 문자열 생성

      // 서로 다른 색상으로 텍스트 출력
      ILI9341_DrawText(BufferText, FONT3, 10, 10, BLACK, WHITE);   HAL_Delay(500);
      ILI9341_DrawText(BufferText, FONT3, 10, 30, BLUE, WHITE);    HAL_Delay(500);
      ILI9341_DrawText(BufferText, FONT3, 10, 50, RED, WHITE);     HAL_Delay(500);
      ILI9341_DrawText(BufferText, FONT3, 10, 70, GREEN, WHITE);   HAL_Delay(500);
      ILI9341_DrawText(BufferText, FONT3, 10, 90, YELLOW, WHITE);  HAL_Delay(500);
      ILI9341_DrawText(BufferText, FONT3, 10, 110, PURPLE, WHITE); HAL_Delay(500);
      ILI9341_DrawText(BufferText, FONT3, 10, 130, ORANGE, WHITE); HAL_Delay(500);
      ILI9341_DrawText(BufferText, FONT3, 10, 150, MAROON, WHITE); HAL_Delay(500);
      ILI9341_DrawText(BufferText, FONT3, 10, 170, WHITE, BLACK);  HAL_Delay(500);
      ILI9341_DrawText(BufferText, FONT3, 10, 190, BLUE, BLACK);   HAL_Delay(500);

      /* ================== [2] 기본 그래픽 요소 출력 ================== */

      // 가로선(Horizontal Line) 출력
      ILI9341_FillScreen(WHITE);
      ILI9341_DrawHLine(50, 120, 200, NAVY);  // (X=50, Y=120, 길이=200, 색상=NAVY)
      HAL_Delay(2000);

      // 세로선(Vertical Line) 출력
      ILI9341_FillScreen(WHITE);
      ILI9341_DrawVLine(160, 40, 150, NAVY);  // (X=160, Y=40, 길이=150, 색상=NAVY)
      HAL_Delay(2000);

      // 원(Circle) 출력 - 비어 있는 원
      ILI9341_FillScreen(WHITE);
      ILI9341_DrawHollowCircle(160, 120, 80, BLACK);  // 중심(160,120), 반지름 80, 검은색
      HAL_Delay(2000);

      // 원(Circle) 출력 - 채워진 원
      ILI9341_FillScreen(WHITE);
      ILI9341_DrawFilledCircle(160, 120, 80, GREEN);  // 중심(160,120), 반지름 80, 초록색
      HAL_Delay(2000);

      // 채워진 사각형 출력
      ILI9341_FillScreen(WHITE);
      ILI9341_DrawRectangle(50, 50, 220, 140, YELLOW);  // 시작점(50,50), 크기(220x140), 색상=노랑
      HAL_Delay(2000);

      // 테두리만 있는 사각형 출력
      ILI9341_FillScreen(WHITE);
      ILI9341_DrawHollowRectangleCoord(50, 50, 270, 190, RED);  // 시작점(50,50), 끝점(270,190), 색상=빨강
      HAL_Delay(2000);

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
